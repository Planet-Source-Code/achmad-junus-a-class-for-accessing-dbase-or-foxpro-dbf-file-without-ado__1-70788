Title: A Class for accessing dBase or FoxPro dbf file without ADO
Description: This class is made to access dbf file. This class can read and write to a .DBF file. This class can create a new file, and creating fields as well.
Some additional functions are provided, such as, search record, find text, search distinct value, etc.<br>
Good or bad, please leave your comment and vote. :)

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=70788&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
